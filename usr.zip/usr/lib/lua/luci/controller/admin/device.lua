-- Copyright 2008 Steven Barth <steven@midlink.org>
-- Copyright 2008-2011 Jo-Philipp Wich <jow@openwrt.org>
-- Licensed to the public under the Apache License 2.0.
--设备控制界面菜单栏 by sunshy
module("luci.controller.admin.device", package.seeall)--创建模块位于"where"
function index()	
	local fs = require "nixio.fs"
	--向管理员页面添加设备控制栏第一个参数是当前的路径（非文件路径)，alias调用拼接（文件路径在luci/model/cbi下)
	entry({"admin", "device"}, alias("admin", "device", "device"), _("设备控制"), 50).index = true 
	--entry({"admin", "device", "overview"}, template("admin_status/device"), _("设备总览"), 1)
	entry({"admin", "device", "light"}, cbi("admin_device/light"), _("灯光控制"), 2)--系统选项--灯光控制子选项，使用cbi调用	
	entry({"admin", "device", "water_hotter"}, cbi("admin_device/water_hotter"), _("热水器控制"), 4)
	entry({"admin", "device", "getup"}, cbi("admin_device/getup"), _("叫我起床"), 5)
	entry({"admin", "device", "air_conditioning"}, cbi("admin_device/air_conditioning"), _("空调"), 6)
	if fs.access("/sbin/block") then	
		entry({"admin", "device", "fstab"}, cbi("admin_device/fstab"), _("Mount Points"), 50)
		entry({"admin", "device", "fstab", "mount"}, cbi("admin_device/fstab/mount"), nil).leaf = true
		entry({"admin", "device", "fstab", "swap"},  cbi("admin_device/fstab/swap"),  nil).leaf = true
	end


end


