 

m = Map("device", translate("设备控制界面"),
  translate("在这里可以实现控制不同房间的窗帘"))

   s = m:section(TypedSection, "gpio", translate("窗帘控制"))
   s.anonymous = true
   s.addremove = false

   s:tab("room1_curtain", translate("客厅窗帘"))
   s:tab("room2_curtain", translate("主卧窗帘"))
-- s:tab("room3_curtain", translate("次卧窗帘"))


  s:taboption("room1_curtain", Value, "curtain_State_room1",
  translate("客厅吊灯状态"),
  translate("查看照明设备处于开灯还是关灯状态"))

  s:taboption("room1_curtain", Value, "gpio_no__curtain_room1",
  translate("gpio号码"),
  translate("查看是哪个针脚号控制"))

  s:taboption("room2_curtain", Value, "curtain_State_room2",
  translate("设备状态"),
  translate("查看设备处于开灯还是关灯状态"))

  s:taboption("room2_curtain", Value, "gpio_no__curtain_room2",
  translate("gpio号码"),
  translate("查看是哪个针脚号控制"))
--客厅
  button = s:taboption("room1_curtain", Button, "button", translate("客厅开窗帘"))
  button.inputtitle = translate("开窗帘")
  button.inputstyle = "apply" --设置按钮样式
  function button.write(self, section, value)
        -- luci.sys.call("echo 18 > /sys/class/gpio/export")
        -- luci.sys.call("echo out > /sys/class/gpio/gpio18/direction")
        -- luci.sys.call("echo 1 > /sys/class/gpio/gpio18/value")

        -- luci.sys.call("uci set device.@gpio[0].led_State=开启状态")
        -- luci.sys.call("uci commit")     
  end
  button1 = s:taboption("room1_curtain", Button, "button1", translate("客厅关窗帘"))
  button1.inputtitle = translate("关窗帘")
  button1.inputstyle = "apply"
  function button1.write(self,section,value)
       -- luci.sys.call("echo in > /sys/class/gpio/gpio18/direction")
       -- luci.sys.call("echo 0 > /sys/class/gpio/gpio18/value")

       -- luci.sys.call("uci set device.@gpio[0].led_State=关闭状态")
       -- luci.sys.call("uci commit")
  end

--主卧
  button = s:taboption("room2_curtain", Button, "button", translate("开灯起床床"))
  button.inputtitle = translate("开灯")
  button.inputstyle = "apply" --设置按钮样式
  function button.write(self, section, value)
        -- luci.sys.call("echo 18 > /sys/class/gpio/export")
        -- luci.sys.call("echo out > /sys/class/gpio/gpio18/direction")
        -- luci.sys.call("echo 1 > /sys/class/gpio/gpio18/value")
        
  end
  button1 = s:taboption("room2_curtain", Button, "button1", translate("关灯睡觉觉"))
  button1.inputtitle = translate("关灯")
  button1.inputstyle = "apply"
  function button1.write(self,section,value)
       -- luci.sys.call("echo in > /sys/class/gpio/gpio18/direction")
       -- luci.sys.call("echo 0 > /sys/class/gpio/gpio18/value")
  end

return m