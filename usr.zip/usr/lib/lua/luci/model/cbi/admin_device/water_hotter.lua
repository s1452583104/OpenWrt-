m = Map("device", translate("设备控制界面"),
  translate("在这里可以控制热水器，喝水&洗澡"))

   s = m:section(TypedSection, "gpio", translate("热水器控制"))
   s.anonymous = true
   s.addremove = false
   s:tab("bathroom", translate("洗澡间"))
   -- s:tab("drink", translate("热水壶"))
  s:taboption("bathroom", Value, "led_State_bathroom",
  translate("洗澡间热水器状态"),
  translate("查看洗澡间热水器是否工作"))

  s:taboption("bathroom", Value, "gpio_no_bathroom",
  translate("gpio号码"),
  translate("查看是哪个针脚号控制"))--默认19号
  button = s:taboption("bathroom", Button, "button", translate("热水器预热"))
  button.inputtitle = translate("开启热水器")
  button.inputstyle = "apply" --设置按钮样式
  function button.write(self, section, value)  	    
        luci.sys.call("echo 19 > /sys/class/gpio/export")
        luci.sys.call("echo out > /sys/class/gpio/gpio19/direction")
        luci.sys.call("echo 1 > /sys/class/gpio/gpio19/value")
        luci.sys.call("uci set device.@gpio[0].led_State_bathroom=热水器在10分钟后自动关闭")
        luci.sys.call("uci commit") --更新读取状态
	    hours=os.date("%H",time)
	    mins=os.date("%M",time)
	    mins=mins+10
	    if mins>60 then
	    	hours=hours+1
	    	if hours>=24 then
	    		hours=0
	    	end 	
	    end
	    mins=mins%60
        luci.sys.call("echo '"..mins.." "..hours.." * * * /shell/gpio/stop19.sh' > /etc/crontabs/root")
        luci.sys.call("echo '                                 ' >> /etc/crontabs/root")      
  end
  button1 = s:taboption("bathroom", Button, "button1", translate("热水器关闭"))
  button1.inputtitle = translate("热水器关闭")
  button1.inputstyle = "apply"
  function button1.write(self,section,value)
       luci.sys.call("echo in > /sys/class/gpio/gpio19/direction")
       luci.sys.call("echo 0 > /sys/class/gpio/gpio19/value")
       luci.sys.call("uci set device.@gpio[0].led_State_bathroom=加热状态终止")
       luci.sys.call("uci commit")
  end
return m