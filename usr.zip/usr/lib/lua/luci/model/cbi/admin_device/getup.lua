 --首先从创建一个map开始，配置路径在etc/config/network 即UCI统一配置方法
m = Map("device", translate("究极闹钟"), translate("使用惨绝人寰的方式叫我起床"))
--获取所有类型为device的section并且生成html文件
  s = m:section(TypedSection, "getup_clock", translate("闹钟"))

  s.anonymous = true
  s.addremove = false
--创建一个表单
  s:tab("room1", translate("主卧"))

  s:taboption("room1", Value, "time_hours",
  translate("小时"),
  translate("设置闹钟的小时值"))
  s:taboption("room1", Value, "time_mins",
  translate("分钟"),
  translate("设置闹钟的分钟值"))
--创建一个按钮1控制开灯


  button = s:taboption("room1", Button, "button", translate("开启闹钟"))
  button.inputtitle = translate("开启闹钟")
  button.inputstyle = "apply" --设置按钮样式
--使用call（）方法调用shell脚本
  function button.write(self, section, value)
  	    -- hours=room1.time_hours
  	    -- mins=room1.time_mins
  	     h=luci.sys.exec("uci get device.@getup_clock[0].time_hours")
  	     m=luci.sys.exec("uci get device.@getup_clock[0].time_mins")
  	     hours=string.sub(h,1,2)
  	     if string.sub(h,2,2)==' ' then
  	     	hours=string.sub(h,1,1)
  	     end

  	     mins=string.sub(m,1,2)
  	     if string.sub(m,2,2)==' ' then
  	     	hours=string.sub(m,1,1)
  	     end

  	     if hours then 
  	     	if mins then
            luci.sys.call("echo '"..mins.." "..hours.." * * * /shell/gpio/start18.sh' >> /etc/crontabs/root")
            luci.sys.call("echo '                                 ' >> /etc/crontabs/root")
            end
         else 
         	luci.sys.call("echo '0 1 1 1 * /shell/gpio/start18.sh' >> /etc/crontabs/root")
         end
        -- luci.sys.call("                                                        ' >>>> /etc/crontabs/root")
       
       
  end
  button1 = s:taboption("room1", Button, "button1", translate("关闭闹钟"))
  button1.inputtitle = translate("关闭闹钟")
  button1.inputstyle = "apply"
  function button1.write(self,section,value)
       luci.sys.call("killall -9 madplay&")
  end


return m