 

m = Map("device", translate("设备控制界面"),
  translate("在这里可以实现控制不同房间的空调"))

   s = m:section(TypedSection, "infrared", translate("红外控制：红外控制正在学习中"))
   s.anonymous = true
   s.addremove = false

   s:tab("room1", translate("客厅"))
   s:tab("room2", translate("主卧"))

  
return m