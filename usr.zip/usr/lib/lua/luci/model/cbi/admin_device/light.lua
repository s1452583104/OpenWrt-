 
--uci
m = Map("device", translate("设备控制界面"),
  translate("在这里可以实现控制不同房间的灯光"))

   s = m:section(TypedSection, "gpio", translate("灯光控制"))
   s.anonymous = true
   s.addremove = false

   s:tab("livingroom", translate("客厅"))
  -- s:tab("bedroom", translate("主卧"))


  s:taboption("livingroom", Value, "led_State_livingroom",
  translate("客厅吊灯状态"),
  translate("查看照明设备处于开灯还是关灯状态"))

  s:taboption("livingroom", Value, "gpio_no_livingroom",
  translate("gpio号码"),
  translate("查看是哪个针脚号控制"))

  -- s:taboption("bedroom", Value, "led_State_bedroom",
  -- translate("设备状态"),
  -- translate("查看设备处于开灯还是关灯状态"))

  -- s:taboption("bedroom", Value, "gpio_no_bedroom",
  -- translate("gpio号码"),
  -- translate("查看是哪个针脚号控制"))


 --客厅灯光    
  button = s:taboption("livingroom", Button, "button", translate("客厅开灯"))
  button.inputtitle = translate("开灯")
  button.inputstyle = "apply" --设置按钮样式
  function button.write(self, section, value)
        luci.sys.call("echo 18 > /sys/class/gpio/export")
        luci.sys.call("echo out > /sys/class/gpio/gpio18/direction")
        luci.sys.call("echo 1 > /sys/class/gpio/gpio18/value")
        luci.sys.call("uci set device.@gpio[0].led_State_livingroom=开启状态")
        luci.sys.call("uci commit")

     end
  button1 = s:taboption("livingroom", Button, "button1", translate("客厅关灯"))
  button1.inputtitle = translate("关灯")
  button1.inputstyle = "apply"
  function button1.write(self,section,value)
       luci.sys.call("echo in > /sys/class/gpio/gpio18/direction")
       luci.sys.call("echo 0 > /sys/class/gpio/gpio18/value")
       luci.sys.call("uci set device.@gpio[0].led_State_livingroom=关闭状态")
       luci.sys.call("uci commit")
  end

    --主卧灯光
  -- button2= s:taboption("bedroom", Button, "button2", translate("主卧开灯"))
  -- button2.inputtitle = translate("开灯")
  -- button2.inputstyle = "apply" --设置按钮样式
  -- function button2.write(self, section, value)
  --       luci.sys.call("echo 14 > /sys/class/gpio/export")
  --       luci.sys.call("echo out > /sys/class/gpio/gpio14/direction")
  --       luci.sys.call("echo 1 > /sys/class/gpio/gpio14/value")
  --       luci.sys.call("uci set device.@gpio[0].led_State_bedroom=开启状态")
  --       luci.sys.call("uci commit")
        
  -- end
  -- button3 = s:taboption("bedroom", Button, "button3", translate("主卧关灯"))
  -- button3.inputtitle = translate("关灯")
  -- button3.inputstyle = "apply"
  -- function button3.write(self,section,value)
  --      luci.sys.call("echo in > /sys/class/gpio/gpio14/direction")
  --      luci.sys.call("echo 0 > /sys/class/gpio/gpio14/value")
  --      luci.sys.call("uci set device.@gpio[0].led_State_bedroom=关闭状态")
  --       luci.sys.call("uci commit")
  -- end

return m