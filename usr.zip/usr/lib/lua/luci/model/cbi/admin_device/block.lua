 

m = Map("device", translate("设备控制界面"),
  translate("在这里可以实现控制不同房间的灯光"))

   s = m:section(TypedSection, "gpio", translate("灯光控制"))
   s.anonymous = true
   s.addremove = false

   s:tab("room1", translate("客厅"))
   s:tab("room2", translate("主卧"))
-- s:tab("tftp", translate("TFTP Settings"))
-- s:tab("advanced", translate("Advanced Settings"))

  s:taboption("room1", Value, "led_State",
  translate("客厅吊灯状态"),
  translate("查看照明设备处于开灯还是关灯状态"))

  s:taboption("room1", Value, "gpio_no",
  translate("gpio号码"),
  translate("查看是哪个针脚号控制"))

  s:taboption("room2", Value, "led_State1",
  translate("设备状态"),
  translate("查看设备处于开灯还是关灯状态"))

  s:taboption("room2", Value, "gpio_no1",
  translate("gpio号码"),
  translate("查看是哪个针脚号控制"))

  button = s:taboption("room1", Button, "button", translate("梦魇走了"))
  button.inputtitle = translate("主卧开灯")
  button.inputstyle = "apply" --设置按钮样式
  function button.write(self, section, value)
        luci.sys.call("echo 18 > /sys/class/gpio/export")
        luci.sys.call("echo out > /sys/class/gpio/gpio18/direction")
        luci.sys.call("echo 1 > /sys/class/gpio/gpio18/value")

        luci.sys.call("uci set device.@gpio[0].led_State=开启状态")
        luci.sys.call("uci commit")

        
  end
  button1 = s:taboption("room1", Button, "button1", translate("梦魇来了"))
  button1.inputtitle = translate("主卧关灯")
  button1.inputstyle = "apply"
  function button1.write(self,section,value)
       luci.sys.call("echo in > /sys/class/gpio/gpio18/direction")
       luci.sys.call("echo 0 > /sys/class/gpio/gpio18/value")

       luci.sys.call("uci set device.@gpio[0].led_State=关闭状态")
       luci.sys.call("uci commit")
  end

  button = s:taboption("room2", Button, "button", translate("开灯起床床"))
  button.inputtitle = translate("开灯")
  button.inputstyle = "apply" --设置按钮样式
  function button.write(self, section, value)
        luci.sys.call("echo 18 > /sys/class/gpio/export")
        luci.sys.call("echo out > /sys/class/gpio/gpio18/direction")
        luci.sys.call("echo 1 > /sys/class/gpio/gpio18/value")
        
  end
  button1 = s:taboption("room2", Button, "button1", translate("关灯睡觉觉"))
  button1.inputtitle = translate("关灯")
  button1.inputstyle = "apply"
  function button1.write(self,section,value)
       luci.sys.call("echo in > /sys/class/gpio/gpio18/direction")
       luci.sys.call("echo 0 > /sys/class/gpio/gpio18/value")
  end

return m