 --首先从创建一个map开始，配置路径在etc/config/network 即UCI统一配置方法
m = Map("network", translate("GPIO串口控制"), translate("在这里可以实现控制不同房间的灯光"))
--获取所有类型为gpioset的section并且生成html文件
  s = m:section(TypedSection, "gpioset", translate("GPIO控制"))
--创建一个表单
  s:tab("room1", translate("客厅"))
--创建一个按钮1控制开灯
  button = s:taboption("room1", Button, "button", translate("按钮1"))
  button.inputtitle = translate("开灯")
  button.inputstyle = "apply" --设置按钮样式
--使用call（）方法调用shell脚本
  function button.write(self, section, value)
        luci.sys.call("echo 18 > /sys/class/gpio/export")
        luci.sys.call("echo out > /sys/class/gpio/gpio18/direction")
        luci.sys.call("echo 1 > /sys/class/gpio/gpio18/value")
        -- luci.sys.call("echo 19 > /sys/class/gpio/export")
        -- luci.sys.call("echo out > /sys/class/gpio/gpio19/direction")
        -- luci.sys.call("echo 0 > /sys/class/gpio/gpio19/value")
  end
  button1 = s:taboption("room1", Button, "button1", translate("按钮2"))
  button1.inputtitle = translate("关灯")
  button1.inputstyle = "apply"
  function button1.write(self,section,value)
       luci.sys.call("echo in > /sys/class/gpio/gpio18/direction")
       luci.sys.call("echo 0 > /sys/class/gpio/gpio18/value")
  end

  
  s:tab("room2", translate("卧室1"))
--创建一个按钮1控制开灯
  button = s:taboption("room2", Button, "button", translate("按钮1"))
  button.inputtitle = translate("开灯")
  button.inputstyle = "apply" --设置按钮样式
--使用call（）方法调用shell脚本
  function button.write(self, section, value)
        luci.sys.call("echo 18 > /sys/class/gpio/export")
        luci.sys.call("echo out > /sys/class/gpio/gpio18/direction")
        luci.sys.call("echo 1 > /sys/class/gpio/gpio18/value")
        -- luci.sys.call("echo 19 > /sys/class/gpio/export")
        -- luci.sys.call("echo out > /sys/class/gpio/gpio19/direction")
        -- luci.sys.call("echo 0 > /sys/class/gpio/gpio19/value")
  end
  button1 = s:taboption("room2", Button, "button1", translate("按钮2"))
  button1.inputtitle = translate("关灯")
  button1.inputstyle = "apply"
  function button1.write(self,section,value)
       luci.sys.call("echo in > /sys/class/gpio/gpio18/direction")
       luci.sys.call("echo 0 > /sys/class/gpio/gpio18/value")
  end

return m