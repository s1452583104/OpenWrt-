-- Copyright 2008 Steven Barth <steven@midlink.org>
-- Copyright 2008-2011 Jo-Philipp Wich <jow@openwrt.org>
-- Licensed to the public under the Apache License 2.0.
--设备控制界面菜单栏 by sunshy
module("luci.controller.admin.device_control", package.seeall)--创建模块位于"where"

function index(  )
	--向管理员页面添加设备控制栏第一个参数是当前的路径（非文件路径)，alias调用拼接（文件路径在luci/model/cbi下)
	entry({"admin", "device_control"}, alias("admin", "system", "device_control"), _("设备控制"), 50).index = true 
	entry({"admin", "device_control", "light_control"}, cbi("admin_device_control/light_control"), _("灯光控制"), 1)--灯光控制子选项，使用cbi调用
end
